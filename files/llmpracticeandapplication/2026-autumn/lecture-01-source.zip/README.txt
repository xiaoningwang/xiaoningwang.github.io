第一讲 应用场景与智能体

本包包含lecture-01.Rmd、中传课件主题cuc-reference.sty及三张配套图片。
请解压至同一目录，使用R、rmarkdown、Pandoc和支持ctex的XeLaTeX编译。
在R中运行：rmarkdown::render("lecture-01.Rmd")
